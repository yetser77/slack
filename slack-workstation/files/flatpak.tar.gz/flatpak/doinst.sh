flatpak remote-list --system &> /dev/null || :
